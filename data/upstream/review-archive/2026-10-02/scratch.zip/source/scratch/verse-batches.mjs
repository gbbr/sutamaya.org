// Writes the verse round's batches: the chosen stanzas, each with the line before and after it, 50
// stanzas to a batch; neighbouring stanzas of one text are shown together.
// Usage: node verse-batches.mjs <stanzas.json> <flagged|unflagged:N:seed|all> <out dir> <first batch number>
import fs from 'node:fs';
import path from 'node:path';

const [IN, PICK, OUT, FIRST] = process.argv.slice(2);
const stanzas = JSON.parse(fs.readFileSync(IN, 'utf8'));
let chosen;
if (PICK === 'flagged') chosen = stanzas.filter((s) => s.why.length);
else if (PICK === 'all') chosen = stanzas;
else {
  const [, n, seed0] = PICK.split(':');
  let seed = Number(seed0);
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const pool = stanzas.filter((s) => !s.why.length);
  const picked = new Set();
  while (picked.size < Math.min(Number(n), pool.length)) picked.add(Math.floor(rnd() * pool.length));
  chosen = [...picked].sort((a, b) => a - b).map((i) => pool[i]);
}

const row = (l, ctx) => `${ctx ? '(context) ' : ''}${l.key} | P: ${l.p} | S: ${l.s || '(none)'} | T: ${l.t || '(none)'}`;
// Items: runs of stanzas of one text that follow each other.
const items = [];
for (const s of chosen) {
  const last = items.at(-1);
  if (last && last.uid === s.uid && last.stanzas.at(-1).after?.key === s.lines[0].key) last.stanzas.push(s);
  else items.push({ uid: s.uid, stanzas: [s] });
}
fs.mkdirSync(OUT, { recursive: true });
let n = Number(FIRST), count = 0, buf = [], itemNo = 0;
const flush = () => {
  if (!buf.length) return;
  fs.writeFileSync(path.join(OUT, `batch-${String(n).padStart(3, '0')}.txt`), `${buf.join('\n\n')}\n`);
  console.log(`batch-${String(n).padStart(3, '0')}: ${count} stanzas`);
  n++; count = 0; buf = []; itemNo = 0;
};
for (const it of items) {
  const lines = [];
  const first = it.stanzas[0], lastSt = it.stanzas.at(-1);
  if (first.before) lines.push(row(first.before, true));
  for (const s of it.stanzas) for (const l of s.lines) lines.push(row(l, false));
  if (lastSt.after) lines.push(row(lastSt.after, true));
  buf.push(`## ${++itemNo} ${it.uid}\n${lines.join('\n')}`);
  count += it.stanzas.length;
  if (count >= 50) flush();
}
flush();
