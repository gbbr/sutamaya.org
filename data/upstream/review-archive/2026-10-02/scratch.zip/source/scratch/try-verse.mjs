// Reports how the verse round's fixes fared in a --findings run, and writes the check items for the
// groups that pass, each line with its Pali.
// Usage: node try-verse.mjs <repo> <translator> [<check out file> <n> <seed>]
import fs from 'node:fs';
import path from 'node:path';

const [REPO, T, CHECK_OUT, N, SEED] = process.argv.slice(2);
const review = path.join(REPO, 'data', T, 'review');
const named = new Map();
for (const f of fs.readdirSync(path.join(review, 'hand')).filter((f) => /^verse-\d+\.findings$/.test(f))) {
  for (const line of fs.readFileSync(path.join(review, 'hand', f), 'utf8').split('\n')) {
    const m = /^(\S+:\S+) (?:starts: (.+)|none)$/.exec(line.trim());
    if (m) named.set(m[1], f);
  }
}
const report = JSON.parse(fs.readFileSync(path.join(review, 'findings.json'), 'utf8'));
const mine = report.groups.filter((g) => g.findings.some((f) => named.has(f.key)));
const verdicts = {};
for (const g of mine) verdicts[g.verdict] = (verdicts[g.verdict] ?? 0) + 1;
const others = {};
for (const o of report.others.filter((o) => named.has(o.key))) others[o.status] = (others[o.status] ?? 0) + 1;
const disputed = report.disputed.filter((d) => named.has(d.key)).length;
console.log(`${T}: ${named.size} lines named in ${new Set(named.values()).size} files; groups ${JSON.stringify(verdicts)}; others ${JSON.stringify(others)}; disputed ${disputed}`);
for (const g of mine.filter((g) => g.verdict !== 'passes')) console.log(`  ${g.verdict}: ${g.findings.map((f) => f.key).join(' ')}`);
for (const o of report.others.filter((o) => named.has(o.key) && o.status !== 'already so')) console.log(`  ${o.status}: ${o.key} ${o.starts ?? 'none'}`);

if (CHECK_OUT) {
  const pali = new Map();
  const walk = (dir) => { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name); if (e.isDirectory()) walk(p); else for (const [k, v] of Object.entries(JSON.parse(fs.readFileSync(p, 'utf8')))) pali.set(k, v.trim()); } };
  walk(path.join(REPO, 'data', 'pali', 'sutta', 'kn'));
  let pool = mine.filter((g) => g.verdict === 'passes');
  let seed = Number(SEED ?? 1);
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const picked = [];
  while (pool.length && picked.length < Number(N ?? 50)) picked.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]);
  const name = T === 'bodhi' ? 'Bodhi' : 'Ṭhānissaro';
  const items = picked.map((g, i) => [
    `## ${i + 1} (${name}, ${g.text})`,
    ...g.lines.map((l) => `${l.key} | P: ${pali.get(l.key) ?? ''} | S: ${l.sujato ?? '(none)'}\n    Before: ${l.before || '(none)'}\n    After:  ${l.after || '(none)'}`),
  ].join('\n'));
  fs.writeFileSync(CHECK_OUT, `${items.join('\n\n')}\n`);
  fs.writeFileSync(`${CHECK_OUT}.groups.json`, JSON.stringify(picked.map((g) => g.findings.map((f) => f.key))));
  console.log(`check: ${picked.length} of ${mine.filter((g) => g.verdict === 'passes').length} passing groups written to ${CHECK_OUT}`);
}
