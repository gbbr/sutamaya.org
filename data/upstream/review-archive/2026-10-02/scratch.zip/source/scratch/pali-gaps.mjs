// Which Pali lines a reader could reveal under Sujato's English but not under Bodhi's or Ṭhānissaro's.
// Rule A: the app's own rule (buildBodySegments), fed the translator's English.
// Rule B: every untranslated line joins the nearest translated line above it in its HTML paragraph
//         (a <p>, a stanza), headings and closing lines excepted.
import fs from 'node:fs';
import path from 'node:path';
import { buildBodySegments, stripHtmlTags } from '/Users/azzalos/g/code/gbbr/sutamaya.org/scripts/lib/collections.js';

const ROOT = '/Users/azzalos/g/code/gbbr/sutamaya.org';
const DATA = path.join(ROOT, 'data');
const OUT = process.argv[2] || '.';

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out); else if (e.name.endsWith('.json')) out.push(p);
  }
  return out;
}
const index = (dir) => new Map(walk(dir).map((f) => [path.basename(f).split('_')[0], f]));
const load = (f) => (f && fs.existsSync(f) ? new Map(Object.entries(JSON.parse(fs.readFileSync(f, 'utf8')))) : new Map());
const words = (s) => (s ? s.split(/\s+/).filter(Boolean).length : 0);
const plain = (s) => stripHtmlTags((s || '').replace(/<j>/g, ''));
const suttaOf = (k) => k.slice(0, k.indexOf(':'));
const isTitle = (k) => { const id = k.slice(k.indexOf(':') + 1); return id === '0' || id.startsWith('0.'); };

const paliIdx = index(path.join(DATA, 'pali', 'sutta'));
const sujIdx = index(path.join(DATA, 'sujato.post', 'sutta'));
const htmlIdx = index(path.join(DATA, 'html', 'pli', 'ms', 'sutta'));

// The Pali keys a reader can reveal: each shown segment's own and those of lines joined to it.
function shownA(paliMap, enMap, htmlMap) {
  const tagged = new Map([...paliMap].map(([k, v]) => [k, v.trim() ? `⟦${k}⟧` : '']));
  const keys = new Set();
  for (const s of buildBodySegments(tagged, enMap, htmlMap, new Map())) for (const m of s.pali.matchAll(/⟦([^⟧]+)⟧/g)) keys.add(m[1]);
  return keys;
}

// Each key the app can show at all (not a title, not an uddāna), with its role and HTML paragraph.
function eligible(paliMap, htmlMap) {
  const all = new Map([...paliMap.keys()].map((k) => [k, 'x']));
  const segs = buildBodySegments(paliMap, all, htmlMap, new Map());
  const roles = new Map(segs.map((s) => [s.key, s.role]));
  let para = 0;
  const paraOf = new Map();
  for (const k of paliMap.keys()) {
    const t = htmlMap.get(k) || '';
    if (/<(p|h\d|li|blockquote|dd|dt|tr|td)\b/.test(t) || !t) para++;
    paraOf.set(k, para);
    if (/<\/(p|h\d|li|dd|dt|td)>/.test(t)) para++;
  }
  return { keys: segs.map((s) => s.key), roles, paraOf };
}

function shownB(el, paliMap, enMap) {
  const keys = new Map();
  let above = null;
  for (const k of el.keys) {
    if (!(paliMap.get(k) || '').trim()) continue;
    const en = plain(enMap.get(k));
    const role = el.roles.get(k);
    if (en) { keys.set(k, k); above = k; continue; }
    if (above && role !== 'heading' && role !== 'end' && el.paraOf.get(k) === el.paraOf.get(above)) keys.set(k, above);
    else above = null;
  }
  return keys;
}

const report = {};
for (const t of ['bodhi', 'thanissaro']) {
  const runs = [];
  const tally = {};
  for (const f of walk(path.join(DATA, t, 'sutta'))) {
    const uid = path.basename(f).split('_')[0];
    const coll = f.split('/sutta/')[1].split('/').slice(0, f.includes('/kn/') ? 2 : 1).join('/');
    const tMap = load(f), paliMap = load(paliIdx.get(uid)), sujMap = load(sujIdx.get(uid)), htmlMap = load(htmlIdx.get(uid));
    // Suttas the translation covers: some text beyond the title lines.
    const covered = new Set([...tMap].filter(([k, v]) => !isTitle(k) && plain(v)).map(([k]) => suttaOf(k)));
    const el = eligible(paliMap, htmlMap);
    const suj = shownA(paliMap, sujMap, htmlMap);
    const a = shownA(paliMap, tMap, htmlMap);
    const b = shownB(el, paliMap, tMap);
    const c = (tally[coll] ??= { texts: 0, suj: 0, lostA: 0, lostB: 0, gainB: 0, sujWords: 0, lostBWords: 0 });
    c.texts++;
    let run = null;
    const keys0 = el.keys.filter((k) => covered.has(suttaOf(k)) && (paliMap.get(k) || '').trim());
    const keys = keys0;
    c.stanzas = (c.stanzas || 0) + new Set(keys.filter((k) => el.roles.get(k) === 'verse' && b.has(k)).map((k) => el.paraOf.get(k))).size;
    c.verseLines = (c.verseLines || 0) + keys.filter((k) => el.roles.get(k) === 'verse').length;
    let tw = 0, sw0 = 0;
    for (const k of keys) { if (b.has(k) && suj.has(k)) { tw += words(plain(tMap.get(k))); sw0 += words(plain(sujMap.get(k))); } }
    const ratio = Math.min(1.6, Math.max(0.6, sw0 ? tw / sw0 : 1));
    keys.forEach((k, i) => {
      const sw = words(plain(sujMap.get(k)));
      if (suj.has(k)) { c.suj++; c.sujWords += sw; if (!a.has(k)) c.lostA++; }
      if (b.has(k) && !suj.has(k)) c.gainB++;
      const lost = suj.has(k) && !b.has(k);
      if (lost) {
        c.lostB++; c.lostBWords += sw;
        if (run && run.last === i - 1) { run.keys.push(k); run.sujWords += sw; run.last = i; }
        else { run = { t, coll, uid, keys: [k], sujWords: sw, last: i, idx: i }; runs.push(run); }
      }
    });
    // Neighbours of each run in this text: the translator's and Sujato's English on the line before and after.
    for (const r of runs.filter((r) => r.uid === uid && !r.done)) {
      r.done = true;
      const prev = keys[r.idx - 1], next = keys[r.last + 1];
      r.prev = prev && { key: prev, t: plain(tMap.get(prev)), s: plain(sujMap.get(prev)) };
      r.next = next && { key: next, t: plain(tMap.get(next)), s: plain(sujMap.get(next)) };
      r.sujText = r.keys.map((k) => plain(sujMap.get(k))).join(' ');
      const group = (k) => { const head = k && b.get(k); if (!head) return k && { key: k, t: '', sWords: words(plain(sujMap.get(k))), empty: true };
        const ks = keys.filter((x) => b.get(x) === head); return { key: head, t: plain(tMap.get(head)), sWords: ks.reduce((n, x) => n + words(plain(sujMap.get(x))), 0), lines: ks.length }; };
      r.prevGroup = group(prev); r.nextGroup = group(next); r.ratio = ratio;
      r.roles = r.keys.map((k) => el.roles.get(k) || '');
      r.paraStart = !prev || el.paraOf.get(prev) !== el.paraOf.get(r.keys[0]);
      r.textEnd = !next;
      delete r.last; delete r.idx; delete r.done;
    }
  }
  report[t] = tally;
  fs.writeFileSync(path.join(OUT, `gaps-${t}.json`), JSON.stringify(runs, null, 1));
}
console.log(JSON.stringify(report, null, 1));
