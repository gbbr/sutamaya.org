// Runs of lines the broader rule would show but the app's rule hides, per translation, with what
// sits above them: the translator's line, Sujato's English for it and for the run, and the run's Pali.
import fs from 'node:fs';
import path from 'node:path';
import { buildBodySegments, stripHtmlTags } from '/Users/azzalos/g/code/gbbr/sutamaya.org/scripts/lib/collections.js';
const DATA = '/Users/azzalos/g/code/gbbr/sutamaya.org/data';
function walk(d, o = []) { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p, o); else if (e.name.endsWith('.json')) o.push(p); } return o; }
const index = (d) => new Map(walk(d).map((f) => [path.basename(f).split('_')[0], f]));
const load = (f) => (f && fs.existsSync(f) ? new Map(Object.entries(JSON.parse(fs.readFileSync(f, 'utf8')))) : new Map());
const plain = (s) => stripHtmlTags((s || '').replace(/<j>/g, ''));
const suttaOf = (k) => k.slice(0, k.indexOf(':'));
const isTitle = (k) => { const id = k.slice(k.indexOf(':') + 1); return id === '0' || id.startsWith('0.'); };
const P = index(path.join(DATA, 'pali', 'sutta')), S = index(path.join(DATA, 'sujato.post', 'sutta')), H = index(path.join(DATA, 'html', 'pli', 'ms', 'sutta'));
function shownA(pm, em, hm) { const tg = new Map([...pm].map(([k, v]) => [k, v.trim() ? `⟦${k}⟧` : ''])); const ks = new Set(); for (const s of buildBodySegments(tg, em, hm, new Map())) for (const m of s.pali.matchAll(/⟦([^⟧]+)⟧/g)) ks.add(m[1]); return ks; }
const out = {};
for (const tr of ['bodhi', 'thanissaro', 'sujato']) {
  const runs = [];
  const files = tr === 'sujato' ? [...S.values()] : walk(path.join(DATA, tr, 'sutta'));
  for (const f of files) {
    const uid = path.basename(f).split('_')[0];
    const em = load(f), pm = load(P.get(uid)), sm = load(S.get(uid)), hm = load(H.get(uid));
    if (!pm.size) continue;
    const covered = new Set([...em].filter(([k, v]) => !isTitle(k) && plain(v)).map(([k]) => suttaOf(k)));
    const all = new Map([...pm.keys()].map((k) => [k, 'x']));
    const segs = buildBodySegments(pm, all, hm, new Map());
    const roles = new Map(segs.map((s) => [s.key, s.role]));
    let para = 0; const paraOf = new Map();
    for (const k of pm.keys()) { const t = hm.get(k) || ''; if (/<(p|h\d|li|blockquote|dd|dt|tr|td)\b/.test(t) || !t) para++; paraOf.set(k, para); if (/<\/(p|h\d|li|dd|dt|td)>/.test(t)) para++; }
    const a = shownA(pm, em, hm);
    let above = null, run = null;
    for (const s of segs) {
      const k = s.key;
      if (!(pm.get(k) || '').trim() || !covered.has(suttaOf(k))) continue;
      if (plain(em.get(k))) { above = k; run = null; continue; }
      const role = roles.get(k);
      if (above && role !== 'heading' && role !== 'end' && paraOf.get(k) === paraOf.get(above)) {
        if (!a.has(k)) { if (!run) { run = { uid, head: above, keys: [] }; runs.push(run); } run.keys.push(k); }
      } else { above = null; run = null; }
    }
    for (const r of runs.filter((r) => r.uid === uid && !r.t)) {
      r.t = plain(em.get(r.head)); r.sHead = plain(sm.get(r.head)); r.sRun = r.keys.map((k) => plain(sm.get(k))).join(' '); r.pRun = r.keys.map((k) => pm.get(k).trim()).join(' ');
    }
  }
  out[tr] = runs;
  console.log(tr, 'runs the broader rule would show:', runs.length, 'lines:', runs.reduce((n, r) => n + r.keys.length, 0), '| of which Sujato translates the run:', runs.filter((r) => r.sRun.trim()).reduce((n, r) => n + r.keys.length, 0));
}
fs.writeFileSync('recovered.json', JSON.stringify(out));
