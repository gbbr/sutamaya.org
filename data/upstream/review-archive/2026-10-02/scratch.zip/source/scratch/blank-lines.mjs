// Blank lines (Pali, no English) in Sujato's, Bodhi's and Ṭhānissaro's texts: where they fall, and
// what each joining rule would show under a translated line.
//   current  – the app's rule: a lone blank line joins the line above in its paragraph
//   all      – every blank line joins the nearest translated line above in its HTML paragraph
// For a run joined under "all", the line above is judged a sentence that runs on (its English is
// about as long as Sujato's for it and the run together) or an elision (about as long as Sujato's
// for it alone, or marked with an ellipsis).
import fs from 'node:fs';
import path from 'node:path';
import { buildBodySegments, stripHtmlTags } from '/Users/azzalos/g/code/gbbr/sutamaya.org/scripts/lib/collections.js';

const DATA = '/Users/azzalos/g/code/gbbr/sutamaya.org/data';
const OUT = process.argv[2];
function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out); else if (e.name.endsWith('.json')) out.push(p);
  }
  return out;
}
const index = (dir) => new Map(walk(dir).map((f) => [path.basename(f).split('_')[0], f]));
const load = (f) => (f && fs.existsSync(f) ? new Map(Object.entries(JSON.parse(fs.readFileSync(f, 'utf8')))) : new Map());
const plain = (s) => stripHtmlTags((s || '').replace(/<j>/g, ''));
const words = (s) => (s ? s.split(/\s+/).filter(Boolean).length : 0);
const suttaOf = (k) => k.slice(0, k.indexOf(':'));
const isTitle = (k) => { const id = k.slice(k.indexOf(':') + 1); return id === '0' || id.startsWith('0.'); };
const ELLIPSIS = /…|\.\.\.|\[/;

const paliIdx = index(path.join(DATA, 'pali', 'sutta'));
const sujIdx = index(path.join(DATA, 'sujato.post', 'sutta'));
const htmlIdx = index(path.join(DATA, 'html', 'pli', 'ms', 'sutta'));

function shownCurrent(paliMap, enMap, htmlMap) {
  const tagged = new Map([...paliMap].map(([k, v]) => [k, v.trim() ? `⟦${k}⟧` : '']));
  const keys = new Set();
  for (const s of buildBodySegments(tagged, enMap, htmlMap, new Map())) for (const m of s.pali.matchAll(/⟦([^⟧]+)⟧/g)) keys.add(m[1]);
  return keys;
}
function structure(paliMap, htmlMap) {
  const all = new Map([...paliMap.keys()].map((k) => [k, 'x']));
  const segs = buildBodySegments(paliMap, all, htmlMap, new Map());
  const roles = new Map(segs.map((s) => [s.key, s.role]));
  let para = 0;
  const paraOf = new Map();
  for (const k of paliMap.keys()) {
    const t = htmlMap.get(k) || '';
    if (/<(p|h\d|li|blockquote|dd|dt|tr|td)\b/.test(t) || !t) para++;
    paraOf.set(k, para);
    if (/<\/(p|h\d|li|dd|dt|td)>/.test(t)) para++;
  }
  return { keys: segs.map((s) => s.key).filter((k) => (paliMap.get(k) || '').trim()), roles, paraOf };
}

// Tallies one translation's lines in one text; `ref` is Sujato's English, to weigh a joined run.
function tally(t, st, paliMap, enMap, htmlMap, ref, only, examples, name) {
  const cur = shownCurrent(paliMap, enMap, htmlMap);
  const keys = st.keys.filter((k) => only(k));
  let above = null, run = [];
  const closeRun = () => {
    if (!run.length) return;
    const head = above;
    const kind = run.length === 1 ? 'lone' : 'run';
    t[`${kind}Lines`] += run.length; t[`${kind}s`]++;
    const en = plain(enMap.get(head));
    let judged;
    if (ELLIPSIS.test(en) || run.some((k) => /\bpe\b|…/.test(paliMap.get(k) || ''))) judged = 'elision';
    else if (ref) {
      const a = words(en), s0 = words(plain(ref.get(head))), s1 = s0 + run.reduce((n, k) => n + words(plain(ref.get(k))), 0);
      judged = Math.abs(a - s1) <= Math.abs(a - s0) ? 'runsOn' : 'elision';
    } else judged = 'unjudged';
    t[`${kind}_${judged}`] = (t[`${kind}_${judged}`] ?? 0) + run.length;
    if (examples && kind === 'run' && examples.length < 400) examples.push({ name, head, run, judged, en, pali: run.map((k) => paliMap.get(k)) });
    run = [];
  };
  for (const k of keys) {
    t.lines++;
    const en = plain(enMap.get(k));
    if (en) { closeRun(); above = k; continue; }
    t.blank++;
    if (!cur.has(k)) t.hiddenNow++;
    const role = st.roles.get(k);
    if (above && role !== 'heading' && role !== 'end' && st.paraOf.get(k) === st.paraOf.get(above)) run.push(k);
    else { closeRun(); above = null; t.noLineAbove++; }
  }
  closeRun();
}

const blank = () => ({ lines: 0, blank: 0, hiddenNow: 0, noLineAbove: 0, loneLines: 0, lones: 0, runLines: 0, runs: 0 });
const result = {};
const examples = [];
for (const tr of ['bodhi', 'thanissaro']) {
  const own = blank(), suj = blank();
  for (const f of walk(path.join(DATA, tr, 'sutta'))) {
    const uid = path.basename(f).split('_')[0];
    const tMap = load(f), paliMap = load(paliIdx.get(uid)), sujMap = load(sujIdx.get(uid)), htmlMap = load(htmlIdx.get(uid));
    const covered = new Set([...tMap].filter(([k, v]) => !isTitle(k) && plain(v)).map(([k]) => suttaOf(k)));
    const st = structure(paliMap, htmlMap);
    const only = (k) => covered.has(suttaOf(k));
    tally(own, st, paliMap, tMap, htmlMap, sujMap, only, examples, tr);
    tally(suj, st, paliMap, sujMap, htmlMap, null, only, null, 'sujato');
  }
  result[tr] = own; result[`sujato (${tr}'s texts)`] = suj;
}
// Sujato over the whole canon the app carries.
const whole = blank();
const sujExamples = [];
for (const [uid, f] of sujIdx) {
  const paliMap = load(paliIdx.get(uid)), sujMap = load(f), htmlMap = load(htmlIdx.get(uid));
  if (!paliMap.size) continue;
  tally(whole, structure(paliMap, htmlMap), paliMap, sujMap, htmlMap, null, () => true, sujExamples, 'sujato');
}
result['sujato (all)'] = whole;
fs.writeFileSync(path.join(OUT, 'blank-examples.json'), JSON.stringify({ examples, sujExamples }, null, 1));
console.log('                          lines   blank  hidden now  no line above  lone(n)  runs(n/lines)  run lines: runsOn/elision/unjudged');
for (const [k, v] of Object.entries(result)) {
  console.log(`${k.padEnd(26)}${String(v.lines).padStart(6)}${String(v.blank).padStart(8)}${String(v.hiddenNow).padStart(12)}${String(v.noLineAbove).padStart(15)}${String(v.loneLines).padStart(9)}${`${v.runs}/${v.runLines}`.padStart(15)}   ${v.run_runsOn ?? 0}/${v.run_elision ?? 0}/${v.run_unjudged ?? 0}`);
}
