import fs0 from 'node:fs';
const STOP = new Set(
  ('a an the and or but if of to in on at by for with from as is are was were be been being am this that these those ' +
    'it its he she they them his her hers their theirs there here then than so such not no nor do does did done doing ' +
    'have has had having i me my mine we us our you your yours who whom whose which what when where why how all any both ' +
    'each more most other some own same very can will just should would could may might must shall also into upon about ' +
    'over under again once up down out off only too one ones thus now o oh let'
  ).split(' '),
);

// Returns a word reduced to a crude stem, the same way for every translation.
function stem(w) {
  if (w.length > 4) {
    if (w.endsWith('ies')) w = `${w.slice(0, -3)}y`;
    else if (w.endsWith('ness')) w = w.slice(0, -4);
    else if (w.endsWith('ing')) w = w.slice(0, -3);
    else if (w.endsWith('ed')) w = w.slice(0, -2);
    else if (w.endsWith('ly')) w = w.slice(0, -2);
    else if (w.endsWith('s') && !w.endsWith('ss')) w = w.slice(0, -1);
  }
  if (w.length > 4 && w.endsWith('e')) w = w.slice(0, -1);
  return w;
}

// The terms the three translators render differently, each group read as one word.
const SYNONYMS = [
  'bhikkhu mendicant monk',
  'bhikkhuni nun',
  'bhagava buddha blessed',
  'bhante sir lord',
  'sankhara choice formation fabrication volitional',
  'nibbana extinguishment extinguished quenching quenched unbinding unbound',
  'dukkha suffering stress stressful suffer',
  'adinava drawback danger',
  'assada gratification allure',
  'pajanati understand discern',
  'samadhi immersion concentration composure',
  'jhana absorption',
  'samana ascetic contemplative recluse',
  'brahmana brahmin brahman',
  'deva god deity devata',
  'asava defilement taint effluent fermentation',
  'tathagata realized',
  'dhamma teaching dharma',
  'vinaya training discipline',
  'arahant perfected arahat worthy',
  'nibbida disillusionment revulsion disenchantment disillusioned disenchanted',
  'viraga dispassion fading dispassionate',
  'upadana grasping clinging sustenance grasp cling',
  'samudaya origin origination originate arising',
  'nirodha cessation cease ending',
  'ahara fuel nutriment food',
  'kamma deed action karma',
  'raga greed lust passion',
  'dosa hate hatred aversion',
  'sila ethics ethical virtue virtuous',
  'saddha faith conviction',
  'appamada diligent diligence heedful heedfulness',
  'dhatu element property',
  'ayatana field base media medium',
  'bodhi awakening enlightenment',
  'mano mind intellect',
  'viriya energy persistence',
  'sukha bliss happiness pleasure',
  'domanassa sadness displeasure distress',
  'kusala skillful wholesome',
  'akusala unskillful unwholesome',
  'bhava existence becoming',
  'sampajanna awareness alertness comprehension',
  'anicca impermanent inconstant impermanence inconstancy',
  'vimutti freedom freed release released liberation liberated',
  'panna wisdom discernment',
  'puthujjana ordinary worldling',
];
const CANON = new Map();
for (const group of SYNONYMS) {
  const [head, ...rest] = group.split(' ');
  for (const w of [head, ...rest]) CANON.set(stem(w), head);
}

// The form each word is compared by, or null for one too common to tell lines apart.
const normCache = new Map();
function normWord(raw) {
  let norm = normCache.get(raw);
  if (norm === undefined) {
    const w = raw.normalize('NFD').replace(/\p{M}/gu, '').toLowerCase().replace(/[’']s$/, '').replace(/[’']/g, '');
    norm = w.length < 2 || STOP.has(w) ? null : (CANON.get(stem(w)) ?? stem(w));
    normCache.set(raw, norm);
  }
  return norm;
}
// Flags the stanzas where a translation's lines may sit on the wrong Pali: where Sujato's lines
// don't follow the Pali's order (the segmenter reads each Pali line through his English), or where
// the translation's own lines match another Pali line of the stanza better than their own.
// Usage: node verse-flag.mjs <repo> <translator> <collection dir, e.g. kn> <out.json>
import path from 'node:path';
const fs = fs0;

const [REPO, T, COLL, OUT] = process.argv.slice(2);
const { buildBodySegments, stripHtmlTags } = await import(path.join(REPO, 'scripts/lib/collections.js'));
const DATA = path.join(REPO, 'data');

function walk(dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out); else if (e.name.endsWith('.json')) out.push(p);
  }
  return out;
}
const index = (dir) => new Map(walk(dir).map((f) => [path.basename(f).split('_')[0], f]));
const load = (f) => (f && fs.existsSync(f) ? new Map(Object.entries(JSON.parse(fs.readFileSync(f, 'utf8')))) : new Map());
const plain = (s) => stripHtmlTags((s || '').replace(/<j>/g, '')).replace(/\s+/g, ' ').trim();
const WORD_RE = /[\p{L}\p{N}]+(?:[’'][\p{L}]+)*/gu;
const wordsOf = (text) => [...new Set((text.match(WORD_RE) ?? []).map(normWord).filter(Boolean))];
const isTitle = (k) => { const id = k.slice(k.indexOf(':') + 1); return id === '0' || id.startsWith('0.'); };
const suttaOf = (k) => k.slice(0, k.indexOf(':'));

// The dictionary: each Pali form → the words of its headwords and meanings.
const dictionary = new Map();
for (const { entry, definition } of JSON.parse(fs.readFileSync(path.join(DATA, 'pli2en_dpd.json'), 'utf8')).entries ?? []) {
  const key = entry.toLowerCase();
  const had = dictionary.get(key) ?? new Set();
  for (const def of definition) {
    const lemma = normWord(def.slice(0, def.indexOf(':')).replace(/\s*\d+$/, ''));
    if (lemma) had.add(lemma);
    for (const b of def.matchAll(/<b>(.*?)<\/b>/g)) for (const w of wordsOf(b[1])) had.add(w);
  }
  dictionary.set(key, had);
}
const glossOf = (pali) => {
  const g = new Set();
  for (const w of pali.toLowerCase().match(WORD_RE) ?? []) {
    for (const x of dictionary.get(w) ?? []) g.add(x);
    const n = normWord(w);
    if (n) g.add(n);
  }
  return g;
};

const paliIdx = index(path.join(DATA, 'pali', 'sutta'));
const sujIdx = index(path.join(DATA, 'sujato', 'sutta'));
const htmlIdx = index(path.join(DATA, 'html', 'pli', 'ms', 'sutta'));

// Every stanza the translation covers, line by line.
const stanzas = [];
for (const f of walk(path.join(DATA, T, 'sutta', COLL))) {
  const uid = path.basename(f).split('_')[0];
  const tMap = load(f), paliMap = load(paliIdx.get(uid)), sujMap = load(sujIdx.get(uid)), htmlMap = load(htmlIdx.get(uid));
  const covered = new Set([...tMap].filter(([k, v]) => !isTitle(k) && plain(v)).map(([k]) => suttaOf(k)));
  const all = new Map([...paliMap.keys()].map((k) => [k, 'x']));
  const roles = new Map(buildBodySegments(paliMap, all, htmlMap, new Map()).map((s) => [s.key, s.role]));
  const keys = [...paliMap.keys()];
  let para = 0;
  const paraOf = new Map();
  for (const k of keys) {
    const t = htmlMap.get(k) || '';
    if (/<(p|h\d|li|blockquote|dd|dt|tr|td)\b/.test(t) || !t) para++;
    paraOf.set(k, para);
    if (/<\/(p|h\d|li|dd|dt|td)>/.test(t)) para++;
  }
  const groups = new Map();
  for (const k of keys) if (roles.get(k) === 'verse' && covered.has(suttaOf(k))) (groups.get(paraOf.get(k)) ?? groups.set(paraOf.get(k), []).get(paraOf.get(k))).push(k);
  for (const ks of groups.values()) {
    if (ks.length < 2) continue;
    const lines = ks.map((k) => ({ key: k, p: (paliMap.get(k) || '').trim(), s: plain(sujMap.get(k)), t: plain(tMap.get(k)) }));
    if (!lines.some((l) => l.t)) continue;
    const at = keys.indexOf(ks[0]), end = keys.indexOf(ks.at(-1));
    const ctx = (k) => k && { key: k, p: (paliMap.get(k) || '').trim(), s: plain(sujMap.get(k)), t: plain(tMap.get(k)) };
    stanzas.push({ uid, lines, before: ctx(keys[at - 1]), after: ctx(keys[end + 1]) });
  }
}

// Each word's weight: rarer words tell lines apart better.
const df = new Map();
let docs = 0;
for (const st of stanzas) for (const l of st.lines) for (const text of [l.s, l.t]) {
  if (!text) continue;
  docs++;
  for (const w of wordsOf(text)) df.set(w, (df.get(w) ?? 0) + 1);
}
const idf = (w) => Math.log(docs / (df.get(w) ?? 1));
const sim = (gloss, text) => wordsOf(text).reduce((n, w) => n + (gloss.has(w) ? idf(w) : 0), 0);

// Margin, in word weight, by which another line must match better.
const MARGIN = 2.5;
for (const st of stanzas) {
  const G = st.lines.map((l) => glossOf(l.p));
  const n = st.lines.length;
  const why = [];
  // Sujato's line for each Pali line, if another of his lines matches it clearly better.
  for (let i = 0; i < n; i++) {
    const own = sim(G[i], st.lines[i].s);
    let best = -1, bestScore = own;
    for (let j = 0; j < n; j++) if (j !== i) { const x = sim(G[i], st.lines[j].s); if (x > bestScore) { best = j; bestScore = x; } }
    if (best >= 0 && bestScore - own >= MARGIN) why.push(`S${best + 1}~P${i + 1}`);
  }
  // The translation's lines: one that matches an earlier Pali line better than its own (it sits
  // too low), or a later one whose own line also has text (it sits too high).
  for (let j = 0; j < n; j++) {
    const t = st.lines[j].t;
    if (!t) continue;
    const scores = G.map((g) => sim(g, t));
    let best = j;
    for (let i = 0; i < n; i++) if (scores[i] > scores[best]) best = i;
    if (best === j || scores[best] - scores[j] < MARGIN) continue;
    if (best < j) why.push(`T${j + 1}~P${best + 1}`);
    else if (st.lines[best].t) why.push(`T${j + 1}~P${best + 1}`);
  }
  st.why = why;
}
fs.writeFileSync(OUT, JSON.stringify(stanzas, null, 1));
const flagged = stanzas.filter((s) => s.why.length);
const byS = flagged.filter((s) => s.why.some((w) => w.startsWith('S'))).length;
const byT = flagged.filter((s) => s.why.some((w) => w.startsWith('T'))).length;
console.log(`${T} ${COLL}: ${stanzas.length} stanzas, ${flagged.length} flagged (Sujato's order ${byS}, translation's lines ${byT})`);
